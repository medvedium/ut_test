document.addEventListener('DOMContentLoaded', function (event) {
  const loginForm = document.querySelector('.login-form'),
    registerForm = document.querySelector('.register-form'),
    registerBtn = registerForm.querySelector('.register-button'),
    loginBtn = loginForm.querySelector('.login-button'),
    createAccount = loginForm.querySelector('#create-account'),
    sucsess = document.querySelector('.sucsess'),
    logout = document.querySelector('.logout');

  loginBtn.addEventListener('click', (e) => {
    e.preventDefault();
    loginForm.style.display = 'none';
    sucsess.style.display = 'flex';
  });

  createAccount.addEventListener('click', (e) => {
    e.preventDefault();
    loginForm.style.display = 'none';
    registerForm.style.display = 'flex';
  });

  registerBtn.addEventListener('click', (e) => {
    e.preventDefault();
    registerForm.style.display = 'none';
    loginForm.style.display = 'flex';
  });

  logout.addEventListener('click', (e) => {
    e.preventDefault();
    sucsess.style.display = 'none';
    loginForm.style.display = 'flex';
  });
});